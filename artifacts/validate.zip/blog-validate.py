import boto3
import json
import csv
import os

def convert_to_csv(body):
    json_acceptable_string = body.replace("'", "\"")
    print(json_acceptable_string)
    d = json.loads(json_acceptable_string)
    with open('/tmp/mycsvfile.csv', 'w') as f: 
        w = csv.DictWriter(f, d.keys())
        w.writeheader()
        w.writerow(d)

# TBD: Diagnosis is mandatory, Name
# TBD: SNOMED CT ( Domain level validation )

def validate(body):
    json_acceptable_string = body.replace("'", "\"")

    json_data = json.loads(json_acceptable_string)
    print(json_data)
    zip = json_data['ZIP CODE ']
    id = json_data['ID NUMBER ']

    if(not zip.strip().isdigit()):
        return False, id, "Zip code invalid"
    claim_id = json_data['ID NUMBER ']
    length = len(claim_id.strip())
    print(length)
    if(length != 16):
        return False, id, "Invalid claim Id"
    return True, id, "Ok"


def lambda_handler(event, context):
    body = event['Records'][0]['body']
    
    # Validate 
    res, formid, result = validate(body)
    print(result)
    filename = "result/" + (str(formid)).strip() + ".csv"
    if(res):
        # convert to CSV
        print("upload file")
        convert_to_csv(body)
        resultbucket = os.environ['resultbucket']
        s3 = boto3.resource('s3')
        s3res = s3.Bucket(resultbucket).upload_file('/tmp/mycsvfile.csv', filename) 
        print(s3res)
    else :
        # add to invalid queue and send message
        sqs_client = boto3.client('sqs')
        invalidqueue = os.environ['invalidqueue']
        msg = sqs_client.send_message(QueueUrl=invalidqueue,
                                      MessageBody=str(body)+result)
        print(msg)
        snsbody = "Content:" + str(body) + "Reason:" + str(result)
        # notify
        sns = boto3.client('sns') 
        invalidtopic = os.environ['invalidsns']
        response = sns.publish(
            TopicArn=invalidtopic,
            Message=str(snsbody))

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }



