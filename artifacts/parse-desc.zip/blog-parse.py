import boto3
import json
import csv
from io import StringIO

def lambda_handler(event, context):

    obj=event['Records'][0]['s3']['object']['key']
    bucket=event['Records'][0]['s3']['bucket']['name']
    s3 = boto3.resource('s3')
    obj = s3.Object(bucket, obj)
    data = obj.get()['Body'].read().decode('utf-8')
    f = StringIO(data)
    reader = csv.DictReader(f)
    row1=next(reader)
    data = row1["PROCEDURE"]

    comprehend = boto3.client(service_name='comprehendmedical')
    json_data = comprehend.detect_entities(Text=data)
    entities = json_data['Entities']
    with open('/tmp/cmresult.csv', 'w') as csvfile:
        filewriter = csv.writer(csvfile, delimiter=',',
                            quotechar='|', quoting=csv.QUOTE_MINIMAL)
        filewriter.writerow(['ID NUMBER', 'Category', 'Type', 'Text'])
        for entity in entities:
            filewriter.writerow([row1['ID NUMBER '], entity['Category'], entity['Type'], entity['Text']])

    filename = "resultaggr/" + (str(row1["ID NUMBER "])).strip() + ".csv"

    s3 = boto3.resource('s3')  
    s3.Bucket(bucket).upload_file('/tmp/cmresult.csv', filename)
    print("successfully parsed")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }




